import mysql.connector

def conectar():
    try:
        conn = mysql.connector.connect(
            user="Pruebapagina",
            password="jarabacoa123",
            host="Pruebapagina.mysql.pythonanywhere-services.com",
            database="Pruebapagina$default"
        )
        if conn.is_connected():
            print("Conexión exitosa.")
        return conn
    except mysql.connector.Error as e:
        print(f"Error al conectarse a la base de datos: {e}")
        return None
