import mysql.connector

def conectar():
    try:
        conn = mysql.connector.connect(
            user="Laurapimentel",
            password="Jarabacoa123",
            host="Laurapimentel.mysql.pythonanywhere-services.com",
            database="Laurapimentel$default"
        )
        if conn.is_connected():
            print("Conexión exitosa.")
        return conn
    except mysql.connector.Error as e:
        print(f"Error al conectarse a la base de datos: {e}")
        return None
